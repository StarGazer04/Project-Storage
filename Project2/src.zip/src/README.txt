- William Carlson, carl6785@d.umn.edu, 5801364
- no partner
- ran tests in intellij, using the green play button. both Class and testAllMoves worked when compiled in terminal as well.
- no assumptions
- additional features implememented were a few instance variables to work around not being able to call any other method in board class from game class.
- no known bugs have been found
- no outside sources used
- “I certify that the information contained in this README
  file is complete and accurate. I have both read and followed the course policies
  in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
  William Carlson