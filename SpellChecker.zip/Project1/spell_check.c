#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "dictionary.h"

#define MAX_CMD_LEN 128

// A helper function to spell check a specific file
// 'file_name': Name of the file to spell check
// 'dict': A dictionary containing correct words
int spell_check_file(const char *file_name, const dictionary_t *dict) {
    FILE *file = fopen(file_name, "r");
    if (file == NULL){
        return 1; //cant open the file
    }
    char word[MAX_WORD_LEN];
    int ch;
    int index = 0;
    while((ch = fgetc(file)) != EOF){ 
        if(ch == ' ' || ch == '\n'){
            word[index] = '\0';
            if(dict_find(dict, word) == 1){
                if(ch == ' '){
                    printf("%s ",word);
                }
                else{
                    printf("%s\n", word);
                }
            }
            else{
                if(ch == ' '){
                    printf("%s[X] ",word);
                }
                else{
                    printf("%s[X]\n", word);
                } 
            }
            memset(word, 0, sizeof(word)); // had to look up what memset does. (reference: https://www.tutorialspoint.com/c_standard_library/c_function_memset.htm)
            index = 0;
        }
        else{
            if(index < MAX_WORD_LEN){
                word[index++] = ch;
            }
        }
    }
    fclose(file);
    return 0;
}

/*
 * This is in general *very* similar to the list_main file seen in lab
 */
int main(int argc, char **argv) {
    dictionary_t *dict = create_dictionary(); //used to be NULL, now fixed
    char cmd[MAX_CMD_LEN];
    char word[MAX_WORD_LEN]; //added this myself
    char file[MAX_WORD_LEN];

    // will check if # of argc is more than or equal to 2
    if(argc >= 2){
        dict_free(dict); // free it duh
        dict = read_dict_from_text_file(argv[1]);
        if(dict == NULL){
            printf("Failed to read dictionary from text file\n");
            dict_free(dict);
            return 1;
        }
        else{
            printf("Dictionary successfully read from text file\n");
            if(argc >= 3){
                int result = spell_check_file(argv[2], dict);
                if(result != 0){
                    printf("Spell check failed\n");
                    dict_free(dict);
                    return 0;
                }
                else{
                    
                    dict_free(dict);
                    return 0;
        }
    }
        }
    }

    printf("CSCI 2021 Spell Check System\n");
    printf("Commands:\n");
    printf("  add <word>:              adds a new word to dictionary\n");
    printf("  lookup <word>:           searches for a word\n");
    printf("  print:                   shows all words currently in the dictionary\n");
    printf("  load <file_name>:        reads in dictionary from a file\n");
    printf("  save <file_name>:        writes dictionary to a file\n");
    printf("  check <file_name>: spell checks the specified file\n");
    printf("  exit:                    exits the program\n");

    while (1) {
        printf("spell_check> ");
        if (scanf("%s", cmd) == EOF) {
            printf("\n");
            break;
        }

        if (strcmp("exit", cmd) == 0) {
            break;
        }
        else if (strcmp("add", cmd) == 0){
            if(scanf("%127s", word) == EOF){
                printf("Error: Unable to read word.\n");
            }

            if(((dict -> size) / dict -> table -> length) >= 0.8){
            dict -> table = resize_table(dict -> table);
            }

            int result = dict_insert(dict, word);
            if(result != 0){
                printf("Failed to Insert");
                break;
            }
        }
        else if (strcmp("print", cmd)==0){
            if (dict == NULL) {
                printf("Dictionary is empty.\n");
                break; //delete
            }       
            else {
                dict_print(dict);
    }
        }
        else if (strcmp("lookup", cmd)== 0){
            if(scanf("%127s", word) == EOF){
                printf("Error: Unable to read word.\n");
                break;
            }
            else{
                int result = dict_find(dict, word);
                if (result == 1){
                    printf("'%s' present in dictionary\n", word);
                }
                else{
                    printf("'%s' not found\n", word);
                }
            }
        }
        else if (strcmp("load", cmd)== 0){
            if(scanf("%127s", file) == EOF){
                printf("Error: Unable to read.\n");
                break;
            }
            else{
                dictionary_t *read_dict = read_dict_from_text_file(file);
                if(read_dict == NULL){
                    printf("Failed to read dictionary from text file\n");
                    
                }
                else{
                    // Freed the previously loaded dictionary
                    dict_free(dict);
                    // Assigned the newly loaded dictionary to the main dictionary pointer
                    dict = read_dict;
                    printf("Dictionary successfully read from text file\n");
                }
            }
        }
        else if (strcmp("save", cmd)== 0){
            if(scanf("%127s", file) == EOF){
                printf("Error: Unable to read.\n");
                break;
                
            }
            else{
                int value = write_dict_to_text_file(dict, file);
                if(value == 0){
                    printf("Dictionary successfully written to text file\n");
                }
                else{
                    printf("Dictionary failed to write to text file\n");
                    
                   
                }
            }
        }
        else if (strcmp("check", cmd)== 0){
            if(scanf("%127s", file) == EOF){
                printf("Error: Unable to read.\n");
                break;
                
            }
            else{
                int value = spell_check_file(file, dict);
                if(value == 1){
                    printf("Spell check failed\n");
                }
            }
        }
        else {
            printf("Unknown command %s\n", cmd);
        }
    }

    dict_free(dict); 
    return 0;
}
