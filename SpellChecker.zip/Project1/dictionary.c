#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"

table_t *create_table() {

    table_t *newTable = malloc(sizeof(table_t)); 
    if(newTable == NULL){
        return NULL;
    }
    newTable -> length = INITIAL_HASH_TABLE_SIZE;
    newTable->array = (list_node_t **)calloc(newTable->length, sizeof(list_node_t *)); //had to look this up on google(reference: google search). inititalizes values of the array of the sppecified size
    if(newTable -> array == NULL){ //memory allocation within table_t has failed, must use free()
        free(newTable);
        return NULL;
    }

    return newTable;
}

dictionary_t *create_dictionary() {
    dictionary_t *dict = malloc(sizeof(dictionary_t));
    if (dict == NULL) {
        return NULL;
    }
    dict->table = create_table();
    if (dict->table == NULL) {
        return NULL;
    }
    dict->size = 0;
    return dict;
}

int hash_code(const char* word) {
    // my implementation takes the word and adds up all the ASCII values and returns that value
    int hash = 0;
    while(*word != '\0'){
        hash += *word;
        word++;
    }


    return hash;
}

int dict_insert(dictionary_t *dict, const char *word) {
     if(dict == NULL || word == NULL){
        return -1; //potential edge case
    }
    list_node_t *node = malloc(sizeof(list_node_t)); // new node created in heap
    if(node == NULL){
        return -1; // memory allocation fails
    }
    strncpy(node -> word, word, MAX_WORD_LEN - 1);
    node->word[MAX_WORD_LEN -1] = '\0'; //null termination when the word is copied over
    node -> next = NULL; 

    int index = hash_code(word) % dict->table->length;; // index for insertion
    if(dict -> table -> array[index] == NULL){ // this will be the case for when no collision occurs 
        dict -> table -> array[index] = node;
    }
    else{ //sicne spot in array is taken, must append to bottom on linked list. aka collision occurs
        list_node_t *currentNode = dict->table->array[index];
        while(currentNode->next != NULL){ 
            currentNode = currentNode->next;
        }
        currentNode->next = node;
    }
    dict->size += 1;
    return 0; //successful
}

int dict_find(const dictionary_t *dict, const char *query) {
    if(dict == NULL || query == NULL){
        return 0; //edge case
    }
    int index = hash_code(query);
    list_node_t *currentNode = dict->table->array[index];
    while(currentNode != NULL){
        if(strcmp(currentNode->word, query) == 0){
            return 1; //found
        } 
        currentNode = currentNode->next;
    }  
    return 0; //not found
}

void dict_print(const dictionary_t *dict) {
    if(dict == NULL|| dict->table == NULL || dict->table->array == NULL){// edge case just in case NULL 
        return;
    }
    for(int i = 0; i < dict -> table -> length; i++){
        list_node_t *current = dict -> table -> array[i];
        while (current != NULL){
            printf("%s\n", current -> word);
            current = current -> next;
        }
    }
}

void dict_free(dictionary_t *dict) {
    if(dict == NULL|| dict->table == NULL || dict->table->array == NULL){
        return; //edge case 
    }
    for(int i = 0; i < dict->table->length; i++){ // start by freeing all the linked nodes
        list_node_t *current = dict->table->array[i];
        while(current != NULL){
            list_node_t *currentTemp = current->next;
            free(current); // node 
            current = currentTemp;
        }
    }
    // after freeing the nodes, work from bottom to top based on the stucture in dictionary.h
    free(dict -> table ->array); //array inside hashtable
    free(dict -> table); // hash table
    free(dict); // dictionary
}

table_t* resize_table(table_t* orig){
    if(orig == NULL){
        return NULL;
    }
    table_t *resizeTable = malloc(sizeof(table_t));
    if(resizeTable == NULL){
        return NULL;
    }
    resizeTable -> length = (orig -> length) * 2;
    resizeTable->array = (list_node_t **)calloc(resizeTable -> length, sizeof(list_node_t*));
    if(resizeTable -> array == NULL){ //memory allocation within table_t has failed, must use free()
        free(resizeTable);
        return NULL;
    }
    for(int i = 0; i < orig -> length; i++){
        list_node_t *current = orig->array[i];
        while(current != NULL){
            list_node_t *nextNode = current ->next;
            int index = hash_code(current ->word) % ((resizeTable -> length));
            //checking if initial spot in array is NULL
            if(resizeTable -> array[index] == NULL){
                resizeTable -> array[index] = current;
                current->next = NULL;
            }
            // initial spot is not null, so iterate through until NULL spot is found
            else{
                list_node_t *resizeCurrent = resizeTable-> array[index];
                while(resizeCurrent->next != NULL){
                    resizeCurrent = resizeCurrent -> next;
                }
                resizeCurrent -> next = current;
                current->next = NULL;
            }
            current = nextNode; //using next variable previously stated above.
        }
    }
    free(orig ->array);
    free(orig);
    return resizeTable;
    
}
dictionary_t *read_dict_from_text_file(const char *file_name) {
    dictionary_t *read_dict = create_dictionary();
    FILE *file_handle = fopen(file_name, "r");
    if (file_handle == NULL){
        dict_free(read_dict);
        return NULL; //cant open the file
    }
    char word[MAX_WORD_LEN];
    while(fscanf(file_handle, "%127s", word) == 1){
        dict_insert(read_dict, word);
    }
    fclose(file_handle);

    return read_dict;
}

int write_dict_to_text_file(const dictionary_t *dict, const char *file_name) {
    FILE *write = fopen(file_name, "w");
    if(write == NULL){
        return -1; // cant write to file
    }
    for(int i = 0; i < dict -> table -> length; i++){
        list_node_t *current = dict -> table -> array[i];
        while (current != NULL){
            fprintf(write,"%s\n", current -> word);
            
            current = current -> next;
        }
    }
    fclose(write);
    
    return 0; // success
}
