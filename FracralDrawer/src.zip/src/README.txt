Name: william carlson
Student id: 5801364

- code was compiled using Visual Studio code
- no additional features were implemented in this project, just the requirements
- no known bugs
- outside sources: https://coderanch.com/t/336174/java/changing-colors-statement 
    this source was used to implement a new color shape for every recursion. no code was copied from this website to my project. 
    this website was only used as a way to check how I would go about checking if a Color object was equal to a parameter value.

“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.
William Carlson